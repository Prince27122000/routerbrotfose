# Hacking

### Ha3Mrx Pentesting and Security Hacking

### Best Hacking Tools

### A penetration test, or pen-test, is an attempt to evaluate the security of an IT infrastructure by safely trying to exploit vulnerabilities. These vulnerabilities may exist in operating systems, services and application flaws, improper configurations or risky end-user behavior. Such assessments are also useful in validating the efficacy of defensive mechanisms, as well as, end-user adherence to security policies

### Download&Install

# git clone https://github.com/Ha3MrX/Hacking

#### cd Hacking

#### chmod +x install.sh

#### ./install.sh

#### chmod +x Ha3Mrx.py

#### python Ha3Mrx.py

### ScreenShot

![capture](https://user-images.githubusercontent.com/33704360/38951938-eee9a22c-42fe-11e8-8610-81ad75a4aafa.PNG)

![capture2](https://user-images.githubusercontent.com/33704360/38951953-f9f668d0-42fe-11e8-9901-6bcc7b5feb61.PNG)

![capture3](https://user-images.githubusercontent.com/33704360/38951965-02227fe4-42ff-11e8-9a2d-592084ba9c01.PNG)

### YouTube Channel

https://www.youtube.com/c/HA-MRX

### Viddeo Tutorials

https://www.youtube.com/watch?v=5Io63aB3gs0
