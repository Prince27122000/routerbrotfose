apt-get upgrade && apt-get update
apt-get install git -y
apt-get install python -y && apt-get install python2 -y
apt-get install hydra -y
apt-get install figlet -y
apt-get dist-upgrade
figlet Tools is Installed
echo How to use Ha3MrX
echo Command : python Ha3Mrx.py
